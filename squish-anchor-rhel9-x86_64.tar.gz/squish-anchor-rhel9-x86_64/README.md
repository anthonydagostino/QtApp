# squish-anchor (RHEL 9 x86_64 runtime package)

Headless Qt 6.6.0 anchor process for Squish attachment. No GUI, no QtWidgets/QML,
no X11/Wayland, no display required: it uses `QCoreApplication` only.

**Self-contained.** Nothing has to be installed on the target machine: no Qt, no
container runtime, no extra packages, no network. Unpack and run. The only things used
from the host are glibc (the dynamic loader, libc, libm, libdl, libpthread, librt),
libstdc++ and libgcc_s, which every RHEL 9 system has; for the last two the package even
carries fallback copies that the wrapper uses automatically if the host lacks them.

## Layout

```
squish-anchor-rhel9-x86_64/
├── bin/squish-anchor        ELF x86_64 executable, RUNPATH $ORIGIN/../lib
├── lib/libQt6Core.so.6      Qt 6.6.0 Core (exports Qt_6_PRIVATE_API) + its runtime deps (ICU)
├── lib/fallback/            libstdc++.so.6 / libgcc_s.so.1, used only if the host has none
├── run-squish-anchor.sh     wrapper: prepends lib/ to LD_LIBRARY_PATH, exec()s the binary
├── validate.sh              self-check (needs only bash and ldd; file/readelf optional)
└── README.md                this file
```

## Run

```bash
tar -xzf squish-anchor-rhel9-x86_64.tar.gz
cd squish-anchor-rhel9-x86_64
./run-squish-anchor.sh            # runs until SIGTERM or SIGINT
./run-squish-anchor.sh --once     # logs startup and exits 0
./run-squish-anchor.sh --help
```

`bin/squish-anchor` can also be started directly (its RUNPATH finds `lib/`), but the
wrapper is the supported entry point: it preserves an existing `LD_LIBRARY_PATH`, adds
`lib/` in front of it and `exec()`s the binary, so the PID it logs is the PID to attach
Squish to.

Startup output (stdout), example:

```
2026-01-01T12:00:00.000 squish-anchor[12345]: started pid=12345 version=1.0.0
2026-01-01T12:00:00.001 squish-anchor[12345]: qt runtime=6.6.0 built-against=6.6.0 core-library=/opt/squish-anchor-rhel9-x86_64/lib/libQt6Core.so.6.6.0
2026-01-01T12:00:00.001 squish-anchor[12345]: running event loop until SIGTERM or SIGINT
```

Stop it with `kill -TERM <pid>` (or Ctrl-C); it logs the signal and exits with status 0.

## Validate

```bash
./validate.sh                     # automated checks, works without file/readelf installed
```

or by hand (`file` and `readelf` need the `file` and `binutils` packages; `ldd` is part of glibc):

```bash
file bin/squish-anchor
ldd bin/squish-anchor
readelf -d bin/squish-anchor
readelf --version-info lib/libQt6Core.so.6 | grep Qt_6_PRIVATE_API
./run-squish-anchor.sh --once
```

## Build and bundle manifest

- Built: 2026-10-06T13:50:12Z
- Build environment: Red Hat Enterprise Linux release 9.8 (Plow), glibc 2.34
- Compiler: g++ (GCC) 11.5.0 20240719 (Red Hat 11.5.0-14.0.1)
- Qt:  (Qt 6.6.0 (x86_64-little_endian-lp64 shared (dynamic))
- Qt SDK root at build time: /work/qt-sdk/6.6.0/gcc_64

Bundled in `lib/`:

- libQt6Core.so.6 => libQt6Core.so.6.6.0 (SONAME libQt6Core.so.6) from /work/qt-sdk/6.6.0/gcc_64/lib/libQt6Core.so.6
- libicui18n.so.67 => libicui18n.so.67.1 (SONAME libicui18n.so.67) from /lib64/libicui18n.so.67
- libicuuc.so.67 => libicuuc.so.67.1 (SONAME libicuuc.so.67) from /lib64/libicuuc.so.67
- libicudata.so.67 => libicudata.so.67.1 (SONAME libicudata.so.67) from /lib64/libicudata.so.67

Resolved from the RHEL 9 system (not bundled):

- libstdc++.so.6 => /lib64/libstdc++.so.6
- libm.so.6 => /lib64/libm.so.6
- libgcc_s.so.1 => /lib64/libgcc_s.so.1
- libc.so.6 => /lib64/libc.so.6
- libglib-2.0.so.0 => /lib64/libglib-2.0.so.0
- libgthread-2.0.so.0 => /lib64/libgthread-2.0.so.0
- libpcre.so.1 => /lib64/libpcre.so.1

Fallback copies in `lib/fallback/` (used by the wrapper only if the host lacks them):

- libstdc++.so.6 => libstdc++.so.6.0.29 from /lib64/libstdc++.so.6 (libstdc++-11.5.0-14.0.1.el9.x86_64)
- libgcc_s.so.1 => libgcc_s-11-20240719.so.1 from /lib64/libgcc_s.so.1 (libgcc-11.5.0-14.0.1.el9.x86_64)
- libglib-2.0.so.0 => libglib-2.0.so.0.6800.4 from /lib64/libglib-2.0.so.0 (glib2-2.68.4-19.el9_8.10.x86_64)
- libgthread-2.0.so.0 => libgthread-2.0.so.0.6800.4 from /lib64/libgthread-2.0.so.0 (glib2-2.68.4-19.el9_8.10.x86_64)
- libpcre.so.1 => libpcre.so.1.2.12 from /lib64/libpcre.so.1 (pcre-8.44-4.el9.x86_64)

`bin/squish-anchor` RUNPATH: `$ORIGIN/../lib`
